#definit pions blancs
Tour = 'Tb'
Cavalier = 'Cb'
Fou = 'Fb'
Roi = 'Rb'
Reine = 'Db'
Pion = 'Pb'

#definit pions noirs
Tour = 'Tn'
Cavalier = 'Cn'
Fou = 'Fn'
Roi = 'Rn'
Reine = 'Dn'
Pion = 'Pn'


def affichage(tab, couleur_joueur="blanc"):
    """
    Erwan
    BROKEN
    Affiche en theorie la grille pour l'utilisateur en fonction de sa couleur(qui se trouvera en bas)
    """
    for y in range(len(tab)):
        for x in range(len(tab[y])):

            if couleur_joueur == "blanc":  # Determine le sens d'affichage du tableau
                tmp = tab[y][x]
            else:
                tmp = tab[-y - 1][-x - 1]

            if tmp[0] == "0":
                if (x + y) % 2 == 0:
                    print(" ⬛ ", end='')
                else:
                    print(" ⬜ ", end='')
            elif tmp[0] == "P":
                if tmp[1] == "b":
                    print(" ♙", end='')  # Le pion est decalle selon l'IDE
                else:
                    print(" \u265f", end='')  # Le pion est affiche en tant qu'emoji / est decalle selon l'IDE
            elif tmp[0] == "F":
                if tmp[1] == "b":
                    print(" ♗", end='')
                else:
                    print(" ♝", end='')
            elif tmp[0] == "T":
                if tmp[1] == "b":
                    print(" ♖", end='')
                else:
                    print(" ♜", end='')
            elif tmp[0] == "C":
                if tmp[1] == "b":
                    print(" ♘", end='')
                else:
                    print(" ♞", end='')
            elif tmp[0] == "D":
                if tmp[1] == "b":
                    print(" ♕", end='')
                else:
                    print(" ♛", end='')
            elif tmp[0] == "R":
                if tmp[1] == "b":
                    print(" ♔", end='')
                else:
                    print(" ♚", end='')
        print('')



def echiquier():
    'on établit l échiquier de départ'
    tab = [["0" for y in range(8)] for x in range(8)]
    for x in range(8) :
        for y in range(8) :
            #on place toutes les pièces sans les couleurs
            if x == 1 or x == 6 :
                tab[x][y] = 'P'
            if x == 0 or x == 7 :
                if y == 7 or y == 0:
                    tab[x][y] = 'T'
                if y == 1 or y == 6 :
                    tab[x][y] = 'C'
                if y == 2 or y == 5 :
                    tab[x][y] = 'F'
                if y == 3 and x == 0 or y == 4 and x == 7 :
                    tab[x][y] = 'D'
                if y == 3 and x == 7 or y == 4 and x == 0 :
                    tab[x][y] = 'R'
            #on ajoute les couleurs 
    for x in range(8):
        for y in range(8):
            if x == 0 or x == 1:
                tab[x][y] +='n0'
            if x == 6 or x == 7:
                tab[x][y] += 'b0'
    return tab


def echec(tab):
    'on créé une fonction échec'
    for x in range(8):
        for y in range(8):
            if tab[x][y] != 0 :
                deplacements = piece(tab[x][y], x, y, tab)#on determine les deplacemets possibles de toutes les pièces
                if tab[x][y][1] == 'b' :
                    for k in deplacements :
                        if tab[k] == 'Rn':
                            print("Echec sur Roi Noir")
                            return True
                else :
                    for k in deplacements :
                        if tab[k] == 'Rb':
                            print("Echec sur Roi Blanc")
                            return True


def echec_et_mat(tab):
    'on créé une fonction echec et math'
    if echec(tab) == True :
        for x in range(8):
            for y in range(8):
                if tab[x][y][0] == 'R' : #on determine la position du roi
                    posiibilités_roi = roi(x,y)#on stocke ses possibles mouvements
                    break
        for i in range(8):
            for j in range(8):
                if tab[i][j][1] != tab[x][y][1] :
                    deplacements = piece(tab[i][j], i, j, tab) #on établit les différents mouvements possibles des pièces adverses
        for k in possibilités_roi :
            for r in deplacements :
                if tab[k] == tab[r]: #on compare les 2 listes, si 2 coordonnées correspondent on l'enlève des possibilités de mouvement du roi
                    possibilités_roi.remove(k)
        if len(possibilités_roi) == 0 :
            print('Echec et mat')
            return True









    
    
