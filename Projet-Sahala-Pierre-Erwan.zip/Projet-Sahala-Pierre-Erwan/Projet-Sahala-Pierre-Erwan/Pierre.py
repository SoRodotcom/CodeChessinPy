## x constitue le nombre de lignes
## y constitue le nombre de colonnes
## A MODIFIER/FINIR Il reste a bloquer les pions lors de leurs deplacemet si ils en rencontre d'autre 

from Sahala import echiquier
from Erwan import affichage

def hors_limite(deplacements):
    """
    Enleve les valeures se trouvant hors de l'echiquier du tableau deplacement
    Pierre
    """
    for e in range(len(deplacements)):
        if 0 >= deplacements[e][0] > 8 or 0 >= deplacements[e][1] >= 7:
            del deplacements[e]
    return deplacements

    
def cavalier(x, y, echiquier):
    """
    Il faut verifier la couleur des pieces sur lesquelles on atteri
    Calcule les deplacements possible du cavalier en x,y (respectivement colonne et ligne)
    pierre
    """
    deplacements = [[x + 2, y - 1], [x + 2, y + 1], [x - 2, y - 1], [x - 2, y + 1], [x - 1, y + 2], [x + 1, y + 2],
                    [x - 1, y - 2], [x + 1, y - 2]]
    deplacements = hors_limite(deplacements)  # Supprime les deplacements hors de l'Echiquier
    couleur = echiquier[x][y][1]
    for i in deplacements:
        if echiquier[i[0]][i[1]][2] == couleur:
            del i
    return deplacements


def pion(x, y, tab, name):
    """
    Il faut verifier si une piece se trouve devant le pion avant de le faire avancer
    Calcule les deplacements possible du pion en x,y (respectivement colonne et ligne), tient compte des pieces autours
    Pierre
    """
    if name[1] == "b":  # Determine les deplacements du pion blanc (partennt du bas de l'echiquier)
        deplacements = [[x - 1, y]]
        if y > 1:
            if 0 < x - 1 <= 8 and 0 <= y + 1 < 8:
                if tab[x - 1][y + 1][1] == "n":
                    deplacements.append([x - 1, y + 1])
            if 0 < x - 1 <= 8 and 0 <= y + 1 < 8:
                if tab[x - 1][y - 1][1] == "n":
                    deplacements.append([x - 1, y - 1])
        if name[2] == "0" and tab[x - 2][y] == "00":
            deplacements.append([x - 2, y])

    else:  # Determine les deplacements du pion noir (partent du haut de l'echiquier)
        deplacements = [[x + 1, y]]
        if y < 7:
            if 0 <= x + 1 < 8 and 0 <= y + 1 < 8:
                if tab[x + 1][y + 1][1] == "b":
                    deplacements.append([x + 1, y + 1])
            if 0 <= x - 1 < 8 and 0 <= y - 1 < 8:
                if tab[x + 1][y - 1][1] == "b":
                    deplacements.append([x + 1, y - 1])
        if name[2] == "0" and tab[x + 2][y] == "00":
            deplacements.append([x + 2, y])

    return deplacements


def fou(x, y, echiquier):
    """
    Il faut verifier si des pions se trouvent sur les trajectoires
    Calcule les deplacements possible du fou en x,y (respectivement colonne et ligne)
    Pierre
    """
    deplacements = []
    for i in range(8):
        deplacements.append([x - 1, y - 1])  # diagonale gauche haute
        deplacements.append([x + 1, y - 1])  # diagonale droite haute
        deplacements.append([x - 1, y + 1])  # diagonale gauche basse
        deplacements.append([x + 1, y + 1])  # diagonale droite basse
    deplacements = hors_limite(deplacements)  # Supprime les deplacements hors de l'Echiquier 
    return deplacements


def roi(x, y, echiquier):
    """
    Il faut verifier la couleur des pions sur lesquels on arrive
    Calcule les deplacements possible du roi en x,y (respectivement colonne et ligne)
    Pierre
    """
    deplacements = [[x + 1, y + 1], [x - 1, y + 1], [x + 1, y - 1], [x - 1, y - 1]]
    deplacements = hors_limite(deplacements)  # Supprime les deplacements hors de l'Echiquier
    couleur = echiquier[x][y][1]
    for i in deplacements:
        if echiquier[i[0]][i[1]][2] == couleur:
            del i
    return deplacements


def ligne(x, y, echiquier):
    """
    BROKEN
    Verifie les deplacements possible en ligne
    """
    couleur = echiquier[x][y][1]
    deplacements = []
    
    for i in range(x):  # Verifie la ligne vers le haut
        if echiquier[x-i][y][1] != couleur:
            deplacements.append([x - i, y])
        else:
            break
            
    for i in range(8 - x): # Verifie la ligne vers le bas
        if echiquier[x+i][y][1] != couleur:
            deplacements.append([x + i, y])
        else:
            break
            
    for i in range(y):  # Verifie la ligne vers la gauche
        if echiquier[x][y+i][1] != couleur:
            deplacements.append([x, y - i])
        else:
            break
        
    for i in range(8 - y):  # Verifie la ligne vers la droite
        if echiquier[x][y+i][1] != couleur:
            deplacements.append([x, y + i])
        else:
            break
        
    return deplacements
    
    
def diagonale(x ,y , echiquier):
    """
    BROKEN
    Verifie les deplacements possibles en diagonale
    """
    couleur = echiquier[x][y][1]
    deplacements = []
    
    if x > y :
        for i in range(y):
            if echiquier[x+i][y+i][1] != couleur:
                deplacements.append([x + i, y + i])
            else:
                break
                
    return deplacements



def dame(x, y, echiquier):
    """
    verifier la couleur des pions sur la trajectoire/bloquer la trajectoire
    Calcule les deplacements possible de la dame en x,y (respectivement colonne et ligne)
    Pierre
    """
    deplacements = []
    for i in range(8):
        deplacements.append([x + i, y + i])
        deplacements.append([x - i, y + i])
        deplacements.append([x + i, y - i])
        deplacements.append([x - i, y - i])
        deplacements.append([x + i, y])
        deplacements.append([x - i, y])
        deplacements.append([x, y + i])
        deplacements.append([x, y - i])
    deplacements = hors_limite(deplacements)  # Supprime les deplacements hors de l'Echiquier

    
    return deplacements

def tour(x, y, echiquier):
    """
    Il faut bloquer la tour lorsqu'elle rencontre un pion
    Renvoie les deplacements possible de la tour en x,y (respectivement colonne et ligne
    Pierre
    """
    deplacements = []
    for i in range(8):
        deplacements.append([x + 1, y])  # Bas
        deplacements.append([x - 1, y])  # Haut
        deplacements.append([x, y - 1])  # Gauche
        deplacements.append([x, y + 1])  # Droite
    deplacements = hors_limite(deplacements)  # Supprime les deplacements hors de l'Echiquier
    return deplacements
        

def piece(x, y, tab):
    """
    Renvoie les deplacements en possibles en fonction de la piece selectionee.
    Renvoie None si la case est vide.
    Pierre
    """
    name = tab[x][y]
    deplacements = None
    if name[0] == "P":
        deplacements = pion(x, y, tab, name)
    elif name[0] == "C":
        deplacements = cavalier(x, y, echiquier)
    elif name[0] == "T":
        deplacements = tour(x, y, echiquier)
    elif name[0] == "F":
        deplacements = fou(x, y, echiquier)
    elif name[0] == "D":
        deplacements = dame(x, y, echiquier)
    elif name[0] == "R":
        deplacements = roi(x, y, echiquier)
    return deplacements


affichage(echiquier())
echiquier = echiquier()
#print(echiquier)
print(piece(0, 0, echiquier))

print(ligne(1,5,echiquier))