def affichage(tab, couleur_joueur="blanc"):
    """
    Erwan
    BROKEN
    Affiche en theorie la grille pour l'utilisateur en fonction de sa couleur(qui se trouvera en bas)
    """
    for y in range(len(tab)):
        for x in range(len(tab[y])):

            if couleur_joueur == "blanc":  # Determine le sens d'affichage du tableau
                tmp = tab[y][x]
            else:
                tmp = tab[-y - 1][-x - 1]

            if tmp[0] == "0":
                if (x + y) % 2 == 0:
                    print(" ⬛ ", end='')
                else:
                    print(" ⬜ ", end='')
            elif tmp[0] == "P":
                if tmp[1] == "b":
                    print(" ♙", end='')  # Le pion est decalle selon l'IDE
                else:
                    print(" \u265f", end='')  # Le pion est affiche en tant qu'emoji / est decalle selon l'IDE
            elif tmp[0] == "F":
                if tmp[1] == "b":
                    print(" ♗", end='')
                else:
                    print(" ♝", end='')
            elif tmp[0] == "T":
                if tmp[1] == "b":
                    print(" ♖", end='')
                else:
                    print(" ♜", end='')
            elif tmp[0] == "C":
                if tmp[1] == "b":
                    print(" ♘", end='')
                else:
                    print(" ♞", end='')
            elif tmp[0] == "D":
                if tmp[1] == "b":
                    print(" ♕", end='')
                else:
                    print(" ♛", end='')
            elif tmp[0] == "R":
                if tmp[1] == "b":
                    print(" ♔", end='')
                else:
                    print(" ♚", end='')
        print('')

